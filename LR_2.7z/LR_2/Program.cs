﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace LR_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TextWriter save_out = Console.Out;
            TextReader save_in = Console.In;
            var new_out = new StreamWriter(@"output.txt");
            var new_in = new StreamReader(@"input.txt");
            Console.SetOut(new_out);
            Console.SetIn(new_in);
            //
            double a1, a2, a3, a4,a5;
            double res1, res2;  
            a1 = Convert.ToInt32(Console.ReadLine());
            a2 = Convert.ToInt32(Console.ReadLine());
            a3 = Convert.ToInt32(Console.ReadLine());
            a4 = Convert.ToInt32(Console.ReadLine());
            a5= Convert.ToInt32(Console.ReadLine());

            if (((a1 < 0) && (a1 > 10 * 10 * 10 * 10 * 10)) || ((a2 < 0) && (a2 > 10 * 10 * 10 * 10 * 10)) || ((a3 < 0) && (a3 > 10 * 10 * 10 * 10 * 10)) || ((a4 < 0) && (a4 > 10 * 10 * 10 * 10 * 10)) || ((a5 < 0) && (a5 > 10 * 10 * 10 * 10 * 10)) && ((a3-a5 ==0)||(a3-a1 ==0)))
                Console.WriteLine("ERROR");
            else 
            {
                res1 = Math.Round(((Math.Sqrt(a2 - a1) / Math.Sqrt(a3 - a5)) + Math.Sqrt(a1) / a3 - a1),5);
                Console.WriteLine(res1);
            }
            if (((a1 < 0) && (a1 > 10 * 10 * 10 * 10 * 10)) || ((a2 < 0) && (a2 > 10 * 10 * 10 * 10 * 10)) || ((a3 < 0) && (a3 > 10 * 10 * 10 * 10 * 10)) || ((a4 < 0) && (a4 > 10 * 10 * 10 * 10 * 10)) || ((a5 < 0) && (a5 > 10 * 10 * 10 * 10 * 10)) && ((a2 - a3 == 0) || (a2 - a4 == 0)))
                Console.WriteLine("ERROR");
            else
            {
                res2 = Math.Round(Math.Sqrt(10000 / (a2 - a3)) * 1 / Math.Pow(a2 - a4, 2), 5);
                Console.WriteLine(res2);
                    
            }
            Console.SetOut(save_out); new_out.Close();
            Console.SetIn(save_in); new_in.Close();
            Console.ReadKey();
            
        }
    }
}
