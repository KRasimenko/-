﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LR_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Задание 1\n");
            Console.WriteLine("Лабораторная работа №1");
            Console.WriteLine("");
            Console.WriteLine("Выполнил: Герасименко Константин Васильевич");
            Console.WriteLine("Группа ПИЖ-Б-О 23-1");
            Console.WriteLine("Наименование ЛР: Структура консольного приложения");
            Console.WriteLine("");
            Console.WriteLine("Для завершения работы нажмите любую клавишу...");

            ///////////////////////////////////////////////////////////////////////
            Console.WriteLine("Задание 2\n");

            int a = 123;
            int b = 7;

            string str = "Hello World";

            
            Console.WriteLine(b);
            Console.WriteLine(str);

            Console.WriteLine("Значение переменной а равно {0}", a);
            Console.WriteLine("а значение переменной b равно {0}", b);
            Console.WriteLine("значение a+b = {0} + {1} = {2}",a,b,a+b);


            //////////////////////////////////////////////////////////////////////
            Console.WriteLine("Лабораторная работа №1");
            Console.WriteLine("");
            Console.WriteLine("Выполнил: Герасименко Константин Васильевич 26.09.2005");
            Console.WriteLine("Михайловск, Михайловский переулок,39");
            Console.WriteLine("Любимый предмет в шокле: столовая");
            Console.WriteLine("хобби: я ничего не хочу я нехочун");
            Console.WriteLine("Группа ПИЖ-Б-О 23-1");
            Console.WriteLine("Наименование ЛР: Структура консольного приложения");

            /////////////////////////////////////////////////////////////////////////
            a = 5;
            int z = 2;
            int E = 4;
            int t = 3;
            float U = (35 / a) * z + z * a - ((a + E * t) / 4);
            Console.WriteLine(U);
            Console.ReadKey();

        }
    }
}
