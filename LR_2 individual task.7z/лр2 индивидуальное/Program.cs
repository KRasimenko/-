﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace лр2_индивидуальное
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите значение X: ");
            int x = Convert.ToInt32(Console.ReadLine());
            Console.Write("Введите значение Y: ");
            int y = Convert.ToInt32(Console.ReadLine());
            Console.Write("Введите количество слагаемых: ");
            int col = Convert.ToInt32(Console.ReadLine());
            double res = 0;
            for (int i = 1; i < col; i++)
            {
                double term;
                if (i % 2 == 0) 
                {
                    term = Math.Pow(x, i * 2) * y / (i * (i + 2));

                }
                else
                {
                    term = Math.Pow(y, i * 2 + 1) * x / (i * (i + 2));

                }
                if (i % 2 == 0)
                {
                    term -= term;
                }
                res += term;
                
                      
               
            }
            Console.WriteLine(res);
            Console.ReadKey();
            
        }
    }
}
